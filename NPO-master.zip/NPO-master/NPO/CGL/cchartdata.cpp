#include "cchartdata.h"

CChartData::CChartData(QObject *parent) :
    QObject(parent)
{
}
