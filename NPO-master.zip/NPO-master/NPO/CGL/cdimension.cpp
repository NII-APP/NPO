#include "cdimension.h"

CDimension::CDimension(QObject *parent) :
    QObject(parent)
{
}
