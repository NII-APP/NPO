#include "cchart3d.h"

CChart3d::CChart3d()
{
}
