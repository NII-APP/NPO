#ifndef CGLWIDGETMENU_H
#define CGLWIDGETMENU_H

#include <QMenu>

class CGLWidgetMenu : public QMenu
{
    Q_OBJECT
public:
    explicit CGLWidgetMenu(QWidget *parent = 0);

signals:

public slots:

};

#endif // CGLWIDGETMENU_H
