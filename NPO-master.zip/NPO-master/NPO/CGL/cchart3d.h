#ifndef CCHART3D_H
#define CCHART3D_H
#include "cchart.h"

class CChart3d : public CChart
{
public:
    CChart3d();
};

#endif // CCHART3D_H
