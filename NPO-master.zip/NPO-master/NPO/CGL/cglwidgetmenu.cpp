#include "cglwidgetmenu.h"

CGLWidgetMenu::CGLWidgetMenu(QWidget *parent) :
    QMenu(parent)
{
}
